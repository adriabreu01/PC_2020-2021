#include <iostream>
#include <math.h>

int main() {
  float numbertotest{0}, error_objetivo{1}, error_cometido{1};
  float sumatorio1{1}, sumatorio2{1};
  int iteracion{0};
  do {
    std::cout << "Introduzca el valor de x (|x| < 1): ";
    std::cin >> numbertotest;
    while (fabs(numbertotest) < 0 || fabs(numbertotest) >= 1) {
      std::cout << "Por favor introduzca un numero valido: ";
      std::cin >> numbertotest;
    }
    if (numbertotest == 0) { std::cout << "Fin del programa" << std::endl; break;}
    // Segunda parte
    float valor_real = (1 / (1 + numbertotest));
    std::cout << "Valor real 1 / (1 + " << numbertotest << ") = " << valor_real << std::endl; 
    
    do {
      std::cout << "Introduzca el error objetivo: ";
      std::cin >> error_objetivo;
    } while ((error_objetivo <= 0) || (error_objetivo >= valor_real));
    // Tercera parte
    for (int i = 0; error_cometido >= error_objetivo; ++i) {
      if (i == 0){
        sumatorio1 = 1;
      }
      else if (i == 1) {
        sumatorio1 = sumatorio1 - numbertotest;
      }
      else if ((i % 2 == 0) || (i % 2 != 0)) {
        sumatorio2 = 1;
        for (int j = 0; j < i; ++j) {
          sumatorio2 = sumatorio2 * -1;
          sumatorio2 = sumatorio2 * numbertotest;
        }
        sumatorio1 = sumatorio1 + sumatorio2;
      }
      error_cometido = fabs(valor_real - sumatorio1);
      ++iteracion;
    }
      
    if (error_cometido < error_objetivo) {
      std::cout << "Resultado para " << iteracion << " terminos = " << sumatorio1 << std::endl;
      std::cout << "Error cometido para " << iteracion << " terminos = " << error_cometido << "\n\n";
    } else {
      std::cout << "No ha sido posible calcular el error" << std::endl;
    }
  } while (true);
}